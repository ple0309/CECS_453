package com.example.lab_assignment_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
