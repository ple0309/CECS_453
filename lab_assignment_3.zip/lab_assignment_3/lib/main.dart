import 'package:flutter/material.dart';

void main() {
  runApp(const AffirmationsApp());
}

// Defines the data for each affirmation.
class Affirmation {
  final String message;
  final String imagePath;

  const Affirmation({required this.message, required this.imagePath});
}

// Data displayed in the application.
const List<Affirmation> affirmations = [
  Affirmation(
    message: 'Believe in yourself.',
    imagePath: 'assets/images/image1.jpeg',
  ),
  Affirmation(
    message: 'Keep moving forward.',
    imagePath: 'assets/images/image2.jpeg',
  ),
  Affirmation(
    message: 'Every day is a new beginning.',
    imagePath: 'assets/images/image3.jpeg',
  ),
  Affirmation(
    message: 'You are stronger than you think.',
    imagePath: 'assets/images/image4.jpeg',
  ),
  Affirmation(
    message: 'Never stop learning.',
    imagePath: 'assets/images/image5.jpeg',
  ),
];

class AffirmationsApp extends StatelessWidget {
  const AffirmationsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('Affirmations')),
        body: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: affirmations.length,
          itemBuilder: (BuildContext context, int index) {
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Image.asset(
                    affirmations[index].imagePath,
                    height: 220,
                    fit: BoxFit.cover,
                    semanticLabel: affirmations[index].message,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      affirmations[index].message,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
