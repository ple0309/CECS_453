import 'package:flutter_test/flutter_test.dart';
import 'package:lab_assignment_6/main.dart';

void main() {
  testWidgets('Weather app loads correctly', (WidgetTester tester) async {
    await tester.pumpWidget(const WeatherApp());

    expect(find.text('Weather App'), findsOneWidget);
    expect(find.text('Enter city name'), findsOneWidget);
    expect(find.text('Search Weather'), findsOneWidget);
  });
}
