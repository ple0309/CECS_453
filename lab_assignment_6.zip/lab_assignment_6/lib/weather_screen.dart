import 'package:flutter/material.dart';

import 'weather_service.dart';

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});

  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final TextEditingController cityController = TextEditingController();
  final WeatherService weatherService = WeatherService();

  Map<String, dynamic>? weatherData;
  String? errorMessage;
  bool isLoading = false;

  Future<void> searchWeather() async {
    final city = cityController.text.trim();

    if (city.isEmpty) {
      setState(() {
        errorMessage = 'Please enter a city name';
        weatherData = null;
      });
      return;
    }

    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final result = await weatherService.fetchWeather(city);

      if (!mounted) return;

      setState(() {
        weatherData = result;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        weatherData = null;
        errorMessage = error.toString().replaceFirst('Exception: ', '');
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  String capitalize(String text) {
    if (text.isEmpty) return text;

    return text[0].toUpperCase() + text.substring(1);
  }

  @override
  void dispose() {
    cityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cityName = weatherData?['name'];
    final temperature = weatherData?['main']?['temp'];
    final condition = weatherData?['weather']?[0]?['description'];
    final icon = weatherData?['weather']?[0]?['icon'];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather App'),
        centerTitle: true,
        backgroundColor: Colors.blue.shade200,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextField(
            controller: cityController,
            decoration: const InputDecoration(
              labelText: 'Enter city name',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_city),
            ),
            onSubmitted: (_) {
              searchWeather();
            },
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: isLoading ? null : searchWeather,
            child: const Text('Search Weather'),
          ),
          const SizedBox(height: 30),
          if (isLoading) const Center(child: CircularProgressIndicator()),
          if (errorMessage != null)
            Center(
              child: Text(
                errorMessage!,
                style: const TextStyle(color: Colors.red, fontSize: 18),
              ),
            ),
          if (weatherData != null)
            Column(
              children: [
                Text(
                  cityName.toString(),
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Image.network(
                  'https://openweathermap.org/img/wn/$icon@2x.png',
                  width: 120,
                  height: 120,
                  semanticLabel: condition.toString(),
                ),
                Text(
                  '${(temperature as num).toStringAsFixed(1)}°C',
                  style: const TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  capitalize(condition.toString()),
                  style: const TextStyle(fontSize: 22),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
