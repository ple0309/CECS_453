import 'package:flutter_test/flutter_test.dart';
import 'package:lab_assignment_5/mortgage.dart';

void main() {
  test('Mortgage calculates the monthly payment', () {
    const mortgage = Mortgage(amount: 100000, years: 30, interestRate: 3.5);

    expect(mortgage.monthlyPayment, closeTo(449.04, 0.01));

    expect(mortgage.totalPayment, closeTo(161656.09, 0.01));
  });
}
