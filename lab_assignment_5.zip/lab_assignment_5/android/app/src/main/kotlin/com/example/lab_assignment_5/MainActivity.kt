package com.example.lab_assignment_5

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
