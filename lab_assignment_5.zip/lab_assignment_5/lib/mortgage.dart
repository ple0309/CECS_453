import 'dart:math';

class Mortgage {
  final double amount;
  final int years;
  final double interestRate;

  const Mortgage({
    required this.amount,
    required this.years,
    required this.interestRate,
  });

  double get monthlyPayment {
    final int totalMonths = years * 12;
    final double monthlyRate = interestRate / 100 / 12;

    if (totalMonths <= 0) {
      return 0;
    }

    if (monthlyRate == 0) {
      return amount / totalMonths;
    }

    final double ratePower = pow(1 + monthlyRate, totalMonths).toDouble();

    return amount * monthlyRate * ratePower / (ratePower - 1);
  }

  double get totalPayment {
    return monthlyPayment * years * 12;
  }

  String formatMoney(double value) {
    return '\$${value.toStringAsFixed(2)}';
  }
}
