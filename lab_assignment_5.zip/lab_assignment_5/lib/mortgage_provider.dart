import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'mortgage.dart';

class MortgageProvider extends ChangeNotifier {
  static const String amountKey = 'mortgage_amount';
  static const String yearsKey = 'mortgage_years';
  static const String interestRateKey = 'mortgage_interest_rate';

  final SharedPreferencesAsync preferences = SharedPreferencesAsync();

  double _amount = 100000;
  int _years = 30;
  double _interestRate = 3.5;
  bool _isLoaded = false;

  double get amount => _amount;
  int get years => _years;
  double get interestRate => _interestRate;
  bool get isLoaded => _isLoaded;

  Mortgage get mortgage {
    return Mortgage(
      amount: _amount,
      years: _years,
      interestRate: _interestRate,
    );
  }

  // Loads the previously saved mortgage information.
  Future<void> loadMortgage() async {
    _amount = await preferences.getDouble(amountKey) ?? 100000;
    _years = await preferences.getInt(yearsKey) ?? 30;
    _interestRate = await preferences.getDouble(interestRateKey) ?? 3.5;

    _isLoaded = true;
    notifyListeners();
  }

  // Updates the provider and saves the information permanently.
  Future<void> updateMortgage({
    required double amount,
    required int years,
    required double interestRate,
  }) async {
    _amount = amount;
    _years = years;
    _interestRate = interestRate;

    await Future.wait([
      preferences.setDouble(amountKey, amount),
      preferences.setInt(yearsKey, years),
      preferences.setDouble(interestRateKey, interestRate),
    ]);

    notifyListeners();
  }
}
