import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'mortgage_provider.dart';

class ModifyMortgageScreen extends StatefulWidget {
  const ModifyMortgageScreen({super.key});

  @override
  State<ModifyMortgageScreen> createState() {
    return _ModifyMortgageScreenState();
  }
}

class _ModifyMortgageScreenState extends State<ModifyMortgageScreen> {
  late final TextEditingController amountController;
  late final TextEditingController yearsController;
  late double selectedRate;

  final List<double> interestRates = List.generate(53, (index) {
    return 2 + (index * 0.25);
  });

  @override
  void initState() {
    super.initState();

    final mortgageProvider = context.read<MortgageProvider>();

    amountController = TextEditingController(
      text: mortgageProvider.amount.toStringAsFixed(2),
    );

    yearsController = TextEditingController(
      text: mortgageProvider.years.toString(),
    );

    selectedRate = mortgageProvider.interestRate;
  }

  @override
  void dispose() {
    amountController.dispose();
    yearsController.dispose();
    super.dispose();
  }

  Future<void> finishEditing() async {
    final double? amount = double.tryParse(amountController.text.trim());

    final int? years = int.tryParse(yearsController.text.trim());

    if (amount == null || amount <= 0 || years == null || years <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a valid amount and number of years.'),
        ),
      );
      return;
    }

    final mortgageProvider = context.read<MortgageProvider>();

    await mortgageProvider.updateMortgage(
      amount: amount,
      years: years,
      interestRate: selectedRate,
    );

    if (!mounted) {
      return;
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Modify Mortgage'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: amountController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Amount',
                  prefixText: '\$',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: yearsController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Number of years',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Interest Rate: ${selectedRate.toStringAsFixed(2)}%',
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: RadioGroup<double>(
                  groupValue: selectedRate,
                  onChanged: (double? value) {
                    if (value != null) {
                      setState(() {
                        selectedRate = value;
                      });
                    }
                  },
                  child: ListView.builder(
                    itemCount: interestRates.length,
                    itemBuilder: (context, index) {
                      final double rate = interestRates[index];

                      return RadioListTile<double>(
                        title: Text('${rate.toStringAsFixed(2)}%'),
                        value: rate,
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: finishEditing,
                child: const Text('DONE'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
