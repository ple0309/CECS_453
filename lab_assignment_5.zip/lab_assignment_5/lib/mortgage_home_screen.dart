import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'modify_mortgage_screen.dart';
import 'mortgage_provider.dart';

class MortgageHomeScreen extends StatefulWidget {
  const MortgageHomeScreen({super.key});

  @override
  State<MortgageHomeScreen> createState() {
    return _MortgageHomeScreenState();
  }
}

class _MortgageHomeScreenState extends State<MortgageHomeScreen> {
  bool acceptedTerms = false;

  Widget informationRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 18))),
          Text(
            value,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  void openModifyScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return const ModifyMortgageScreen();
        },
      ),
    );
  }

  Future<void> changeTerms(bool? checked) async {
    if (checked != true) {
      setState(() {
        acceptedTerms = false;
      });
      return;
    }

    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Terms and Conditions'),
          content: const Text(
            'I confirm that I reviewed the mortgage information '
            'and accept the terms and conditions.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('Accept'),
            ),
          ],
        );
      },
    );

    if (!mounted) {
      return;
    }

    setState(() {
      acceptedTerms = confirmed ?? false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mortgage Calculator'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Consumer<MortgageProvider>(
        builder: (context, mortgageProvider, child) {
          if (!mortgageProvider.isLoaded) {
            return const Center(child: CircularProgressIndicator());
          }

          final mortgage = mortgageProvider.mortgage;

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  informationRow(
                    'Amount',
                    mortgage.formatMoney(mortgage.amount),
                  ),
                  informationRow('Years', '${mortgage.years}'),
                  informationRow(
                    'Interest Rate',
                    '${mortgage.interestRate.toStringAsFixed(2)}%',
                  ),
                  const Divider(thickness: 2),
                  informationRow(
                    'Monthly Payment',
                    mortgage.formatMoney(mortgage.monthlyPayment),
                  ),
                  informationRow(
                    'Total Payment',
                    mortgage.formatMoney(mortgage.totalPayment),
                  ),
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: const Text('Terms and Conditions'),
                    value: acceptedTerms,
                    onChanged: changeTerms,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: openModifyScreen,
                    child: const Text('MODIFY DATA'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
